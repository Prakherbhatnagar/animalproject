import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
  useRef,
} from "react";
import { io } from "socket.io-client";
import {
  PawPrint,
  MapPin,
  Bell,
  LogOut,
  ChevronRight,
  Clock,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Loader2,
  Shield,
  Activity,
  ArrowRight,
  Heart,
  Coins,
  Search,
  Users,
  Building2,
  Gift,
  Star,
  Zap,
  Camera,
  Navigation,
  HandHeart,
  TrendingUp,
  Award,
  Phone,
  Mail,
  Instagram,
  Twitter,
  Facebook,
  ChevronDown,
  LayoutDashboard,
  Compass,
} from "lucide-react";
import { GoogleLogin } from "@react-oauth/google";

// ─────────────────────────────────────────────
// TYPES
// ─────────────────────────────────────────────
export type ReportStatus =
  | "pending"
  | "accepted"
  | "in_progress"
  | "completed"
  | "fake";
export type Priority = "low" | "medium" | "high" | "critical";
export type Page =
  | "landing"
  | "login"
  | "reporter"
  | "report-form"
  | "dashboard"
  | "admin"
  | "discover"
  | "ngo"
  | "rewards";
export type AuthMode = "google" | "otp";
export type WizardStep = "details" | "photo" | "location" | "review";

export interface GeoLocation {
  lat: number;
  lng: number;
  address: string;
}

export interface AnimalReport {
  id: string;
  animalType: string;
  animalCondition: string;
  description: string;
  imageDataUrl: string | null;
  imageHash: string | null;
  treatedImageUrl: string | null;
  location: GeoLocation | null;
  status: ReportStatus;
  createdAt: Date;
  updatedAt: Date;
  reporterName: string;
  reporterPhone: string;
  priority: Priority;
  isFlagged: boolean;
}

export interface ToastItem {
  id: string;
  type: "success" | "warning" | "error" | "info";
  title: string;
  message: string;
  icon?: string;
}

export interface AppUser {
  name: string;
  phone: string;
  role: "reporter" | "admin";
  avatar?: string;
}

// ─────────────────────────────────────────────
// MOCK DATA
// ─────────────────────────────────────────────
export const MOCK_REPORTS: AnimalReport[] = [
  {
    id: "RPT-001",
    animalType: "Dog",
    animalCondition: "Injured",
    description: "Brown labrador with a limping hind leg near the park gate.",
    imageDataUrl:
      "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&q=80",
    imageHash: "abc123hash",
    treatedImageUrl:
      "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400&q=80",
    location: { lat: 28.6139, lng: 77.209, address: "Lodhi Garden, New Delhi" },
    status: "in_progress",
    createdAt: new Date(Date.now() - 3600000 * 2),
    updatedAt: new Date(Date.now() - 1800000),
    reporterName: "Priya Sharma",
    reporterPhone: "+91 98765 43210",
    priority: "high",
    isFlagged: false,
  },
  {
    id: "RPT-002",
    animalType: "Cat",
    animalCondition: "Malnourished",
    description: "Grey stray cat with kittens under the highway overpass.",
    imageDataUrl:
      "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&q=80",
    imageHash: "def456hash",
    treatedImageUrl: null,
    location: { lat: 28.6229, lng: 77.2085, address: "Connaught Place, New Delhi" },
    status: "pending",
    createdAt: new Date(Date.now() - 3600000 * 5),
    updatedAt: new Date(Date.now() - 3600000 * 5),
    reporterName: "Rahul Mehta",
    reporterPhone: "+91 87654 32109",
    priority: "critical",
    isFlagged: false,
  },
  {
    id: "RPT-003",
    animalType: "Dog",
    animalCondition: "Healthy",
    description: "Stray dog reported but appears healthy and vaccinated.",
    imageDataUrl:
      "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400&q=80",
    imageHash: "ghi789hash",
    treatedImageUrl: null,
    location: { lat: 28.598, lng: 77.195, address: "Hauz Khas, New Delhi" },
    status: "fake",
    createdAt: new Date(Date.now() - 3600000 * 8),
    updatedAt: new Date(Date.now() - 3600000 * 6),
    reporterName: "Ananya Gupta",
    reporterPhone: "+91 76543 21098",
    priority: "low",
    isFlagged: true,
  },
  {
    id: "RPT-004",
    animalType: "Bird",
    animalCondition: "Injured (Wing)",
    description: "Pigeon with broken wing found near bus stop.",
    imageDataUrl:
      "https://images.unsplash.com/photo-1444464666168-49d633b86797?w=400&q=80",
    imageHash: "jkl012hash",
    treatedImageUrl:
      "https://images.unsplash.com/photo-1535083783855-aaab06f60c12?w=400&q=80",
    location: { lat: 28.641, lng: 77.2209, address: "Karol Bagh, New Delhi" },
    status: "completed",
    createdAt: new Date(Date.now() - 3600000 * 24),
    updatedAt: new Date(Date.now() - 3600000 * 12),
    reporterName: "Dev Kapoor",
    reporterPhone: "+91 65432 10987",
    priority: "medium",
    isFlagged: false,
  },
];

// ─────────────────────────────────────────────
// CONTEXT
// ─────────────────────────────────────────────
interface AppContextType {
  page: Page;
  setPage: (p: Page) => void;
  user: AppUser | null;
  setUser: (u: AppUser | null) => void;
  reports: AnimalReport[];
  addReport: (r: AnimalReport) => void;
  updateReportStatus: (id: string, status: ReportStatus, treatedImageDataUrl?: string) => Promise<void>;
  toasts: ToastItem[];
  addToast: (t: Omit<ToastItem, "id">) => void;
  removeToast: (id: string) => void;
  imageHashes: Set<string>;
  registerHash: (hash: string) => void;
}

const AppContext = createContext<AppContextType | null>(null);
export const useApp = () => {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
};

// ─────────────────────────────────────────────
// SCROLL REVEAL HOOK
// ─────────────────────────────────────────────
function useInView(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setInView(true); },
      { threshold }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, [threshold]);
  return { ref, inView };
}

// ─────────────────────────────────────────────
// TOAST SYSTEM
// ─────────────────────────────────────────────
const toastConfig = {
  success: { bg: "bg-emerald-950/95", border: "border-emerald-500/40", icon: "✅", bar: "bg-emerald-500", title: "text-emerald-300" },
  warning: { bg: "bg-amber-950/95", border: "border-amber-500/40", icon: "⚠️", bar: "bg-amber-500", title: "text-amber-300" },
  error: { bg: "bg-red-950/95", border: "border-red-500/40", icon: "🚨", bar: "bg-red-500", title: "text-red-300" },
  info: { bg: "bg-sky-950/95", border: "border-sky-500/40", icon: "ℹ️", bar: "bg-sky-500", title: "text-sky-300" },
};

function ToastNotification({ toast, onRemove }: { toast: ToastItem; onRemove: () => void }) {
  const cfg = toastConfig[toast.type];
  useEffect(() => {
    const t = setTimeout(onRemove, 4500);
    return () => clearTimeout(t);
  }, [onRemove]);

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border backdrop-blur-2xl shadow-2xl ${cfg.bg} ${cfg.border} p-4 min-w-[300px] max-w-sm`}
      style={{ animation: "slideIn 0.35s cubic-bezier(0.34,1.56,0.64,1) both" }}
    >
      <div className="flex items-start gap-3">
        <span className="text-xl mt-0.5">{toast.icon || cfg.icon}</span>
        <div className="flex-1">
          <p className={`font-semibold text-sm ${cfg.title}`}>{toast.title}</p>
          <p className="text-white/65 text-xs mt-0.5 leading-relaxed">{toast.message}</p>
        </div>
        <button onClick={onRemove} className="text-white/35 hover:text-white/70 transition-colors text-lg leading-none">×</button>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-white/8">
        <div className={`h-full ${cfg.bar} origin-left`} style={{ animation: "shrink 4.5s linear forwards" }} />
      </div>
    </div>
  );
}

function ToastContainer() {
  const { toasts, removeToast } = useApp();
  return (
    <div className="fixed top-6 right-6 z-[9999] flex flex-col gap-3 pointer-events-none">
      {toasts.map((t) => (
        <div key={t.id} className="pointer-events-auto">
          <ToastNotification toast={t} onRemove={() => removeToast(t.id)} />
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────
// STATUS UTILITIES
// ─────────────────────────────────────────────
export const statusConfig: Record<ReportStatus, { label: string; color: string; bg: string; dot: string }> = {
  pending: { label: "Pending", color: "text-amber-400", bg: "bg-amber-400/15 border-amber-400/30", dot: "bg-amber-400" },
  accepted: { label: "Accepted", color: "text-sky-400", bg: "bg-sky-400/15 border-sky-400/30", dot: "bg-sky-400" },
  in_progress: { label: "In Progress", color: "text-violet-400", bg: "bg-violet-400/15 border-violet-400/30", dot: "bg-violet-400" },
  completed: { label: "Completed", color: "text-emerald-400", bg: "bg-emerald-400/15 border-emerald-400/30", dot: "bg-emerald-400" },
  fake: { label: "Fake Report", color: "text-red-400", bg: "bg-red-400/15 border-red-400/30", dot: "bg-red-400" },
};

export const priorityConfig: Record<Priority, { label: string; color: string }> = {
  low: { label: "Low", color: "text-slate-400" },
  medium: { label: "Medium", color: "text-sky-400" },
  high: { label: "High", color: "text-orange-400" },
  critical: { label: "CRITICAL", color: "text-red-400" },
};

export function StatusBadge({ status }: { status: ReportStatus }) {
  const cfg = statusConfig[status];
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${cfg.color} ${cfg.bg}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot} animate-pulse`} />
      {cfg.label}
    </span>
  );
}

export function timeAgo(date: Date | string): string {
  const diff = Date.now() - new Date(date).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  return `${Math.floor(hrs / 24)}d ago`;
}

// ─────────────────────────────────────────────
// LANDING PAGE
// ─────────────────────────────────────────────
const FEATURES = [
  { icon: "🤖", title: "AI-Powered Matching", desc: "Smart algorithms match lost pets with found reports instantly using image recognition." },
  { icon: "📡", title: "Real-Time Tracking", desc: "Watch your report go from submission to rescue in real-time with live status updates." },
  { icon: "🪙", title: "Reward System", desc: "Earn coins for every rescue report. Redeem them for NGO donations and exclusive badges." },
  { icon: "✅", title: "Verified NGOs", desc: "Every partner NGO is verified, rated, and monitored for response time and transparency." },
  { icon: "⚡", title: "Fast Response", desc: "Average NGO response time under 45 minutes for critical cases in covered areas." },
  { icon: "🗺️", title: "GPS Precision", desc: "Auto-detect your location with reverse geocoding for pinpoint-accurate rescue dispatching." },
];

const TESTIMONIALS = [
  { name: "Priya Mehta", role: "Animal Welfare Volunteer", city: "Delhi", text: "PawRescue changed how our NGO operates. Reports come in structured, with photos and GPS — we've cut response time by 60%.", avatar: "PM" },
  { name: "Arjun Kapoor", role: "Rescue Reporter", city: "Mumbai", text: "I reported an injured dog and within 30 minutes the NGO was on-site. The real-time status updates kept me informed throughout.", avatar: "AK" },
  { name: "Sneha Gupta", role: "NGO Director", city: "Bangalore", text: "The duplicate detection system is incredible. No more wasted resources on double-reports. Our efficiency has doubled.", avatar: "SG" },
];

const HOW_IT_WORKS = [
  { step: "01", icon: <Camera className="w-7 h-7" />, title: "Capture & Report", desc: "Spot an animal in distress? Open the app, take a live photo, and auto-detect your GPS location." },
  { step: "02", icon: <Navigation className="w-7 h-7" />, title: "NGO Gets Notified", desc: "Our AI routes your report to the nearest verified NGO instantly via real-time push alerts." },
  { step: "03", icon: <Heart className="w-7 h-7" />, title: "Animal Gets Rescued", desc: "Track the rescue in real-time. Get notified when the animal is treated and safe." },
];

const IMPACT_STATS = [
  { value: "14,200+", label: "Animals Rescued", color: "text-emerald-400" },
  { value: "480+", label: "Partner NGOs", color: "text-orange-400" },
  { value: "9,100+", label: "Happy Adoptions", color: "text-sky-400" },
  { value: "52K+", label: "Active Reporters", color: "text-violet-400" },
];

function RevealDiv({ children, delay = 0, className = "" }: { children: React.ReactNode; delay?: number; className?: string }) {
  const { ref, inView } = useInView();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: inView ? 1 : 0,
        transform: inView ? "translateY(0)" : "translateY(28px)",
        transition: `opacity 0.6s ease ${delay}ms, transform 0.6s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

function LandingPage() {
  const { setPage } = useApp();
  const [testimonialIdx, setTestimonialIdx] = useState(0);

  useEffect(() => {
    const t = setInterval(() => setTestimonialIdx((i) => (i + 1) % TESTIMONIALS.length), 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="min-h-screen bg-[#06100A] text-white overflow-x-hidden" style={{ fontFamily: "'DM Sans', sans-serif" }}>

      {/* ── NAVBAR ── */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-[#06100A]/80 backdrop-blur-2xl border-b border-white/8">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center shadow-lg shadow-emerald-500/30">
              <PawPrint className="w-4.5 h-4.5 text-white" style={{ width: 18, height: 18 }} />
            </div>
            <span className="font-bold text-lg text-white" style={{ fontFamily: "'Sora', sans-serif" }}>PawRescue</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm text-white/60">
            <a href="#how" className="hover:text-white transition-colors">How It Works</a>
            <a href="#features" className="hover:text-white transition-colors">Features</a>
            <a href="#impact" className="hover:text-white transition-colors">Impact</a>
            <a href="#ngos" className="hover:text-white transition-colors">NGOs</a>
          </div>
          <button
            onClick={() => setPage("login")}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-sm font-semibold transition-all shadow-lg shadow-emerald-500/30 hover:shadow-emerald-400/40"
          >
            Get Started →
          </button>
        </div>
      </nav>

      {/* ── HERO ── */}
      <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1920&q=80"
            alt="Animal rescue"
            className="w-full h-full object-cover object-center opacity-30"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#06100A]/60 via-[#06100A]/40 to-[#06100A]" />
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/3 right-1/4 w-72 h-72 bg-orange-500/8 rounded-full blur-[100px]" />
        </div>

        <div className="relative max-w-6xl mx-auto px-6 py-20 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 text-xs font-semibold mb-6"
              style={{ animation: "fadeUp 0.6s ease both" }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              14,200+ animals rescued and counting
            </div>
            <h1
              className="text-5xl md:text-6xl font-black leading-[1.05] mb-6"
              style={{ fontFamily: "'Sora', sans-serif", animation: "fadeUp 0.7s ease 0.1s both" }}
            >
              Saving Lives,<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-emerald-300">
                One Paw
              </span>
              <br />at a Time
            </h1>
            <p
              className="text-white/60 text-lg leading-relaxed mb-8 max-w-lg"
              style={{ animation: "fadeUp 0.7s ease 0.2s both" }}
            >
              India's first AI-powered animal rescue platform. Report injured strays, connect with verified NGOs, and track every rescue in real-time — together we can make a difference.
            </p>
            <div className="flex flex-wrap gap-3" style={{ animation: "fadeUp 0.7s ease 0.3s both" }}>
              <button
                onClick={() => setPage("login")}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-semibold hover:from-emerald-400 hover:to-emerald-500 transition-all shadow-xl shadow-emerald-500/30"
              >
                <AlertTriangle className="w-4 h-4" /> Report Animal
              </button>
              <button
                onClick={() => setPage("login")}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-white/8 border border-white/15 text-white font-semibold hover:bg-white/12 transition-all"
              >
                <Heart className="w-4 h-4 text-pink-400" /> Adopt a Pet
              </button>
              <button
                onClick={() => setPage("login")}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-orange-500/15 border border-orange-500/30 text-orange-400 font-semibold hover:bg-orange-500/20 transition-all"
              >
                <HandHeart className="w-4 h-4" /> Donate
              </button>
            </div>
          </div>

          {/* Floating Stats Cards */}
          <div className="hidden lg:grid grid-cols-2 gap-4" style={{ animation: "fadeUp 0.8s ease 0.4s both" }}>
            {IMPACT_STATS.map((stat, i) => (
              <div
                key={stat.label}
                className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-5 hover:bg-white/8 hover:border-white/20 transition-all"
                style={{ animationDelay: `${i * 0.1}s` }}
              >
                <p className={`text-3xl font-black mb-1 ${stat.color}`} style={{ fontFamily: "'Sora', sans-serif" }}>{stat.value}</p>
                <p className="text-white/50 text-sm">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 text-white/30">
          <span className="text-xs">scroll</span>
          <ChevronDown className="w-4 h-4 animate-bounce" />
        </div>
      </section>

      {/* ── MOBILE STATS ── */}
      <div className="lg:hidden grid grid-cols-2 gap-3 max-w-lg mx-auto px-6 pb-12">
        {IMPACT_STATS.map((stat) => (
          <div key={stat.label} className="bg-white/5 border border-white/10 rounded-2xl p-4 text-center">
            <p className={`text-2xl font-black ${stat.color}`} style={{ fontFamily: "'Sora', sans-serif" }}>{stat.value}</p>
            <p className="text-white/50 text-xs mt-1">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* ── HOW IT WORKS ── */}
      <section id="how" className="py-24 px-6 max-w-6xl mx-auto">
        <RevealDiv className="text-center mb-16">
          <span className="text-emerald-400 text-sm font-semibold uppercase tracking-widest">Simple & Fast</span>
          <h2 className="text-4xl font-black mt-3 mb-4" style={{ fontFamily: "'Sora', sans-serif" }}>How It Works</h2>
          <p className="text-white/50 max-w-lg mx-auto">Three simple steps stand between a stray animal in distress and a life-saving rescue.</p>
        </RevealDiv>
        <div className="grid md:grid-cols-3 gap-6">
          {HOW_IT_WORKS.map((step, i) => (
            <RevealDiv key={step.step} delay={i * 120} className="relative">
              <div className="bg-white/[0.04] border border-white/10 rounded-3xl p-8 h-full hover:border-emerald-500/30 hover:bg-white/[0.06] transition-all group">
                <div className="absolute -top-3 -left-1 text-7xl font-black text-white/[0.04] leading-none select-none" style={{ fontFamily: "'Sora', sans-serif" }}>{step.step}</div>
                <div className="relative">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/25 flex items-center justify-center text-emerald-400 mb-5 group-hover:scale-110 transition-transform">
                    {step.icon}
                  </div>
                  <h3 className="text-white font-bold text-xl mb-3" style={{ fontFamily: "'Sora', sans-serif" }}>{step.title}</h3>
                  <p className="text-white/50 text-sm leading-relaxed">{step.desc}</p>
                </div>
              </div>
              {i < HOW_IT_WORKS.length - 1 && (
                <div className="hidden md:flex absolute top-1/2 -right-3 z-10 w-6 h-6 rounded-full bg-emerald-500/20 border border-emerald-500/40 items-center justify-center">
                  <ArrowRight className="w-3 h-3 text-emerald-400" />
                </div>
              )}
            </RevealDiv>
          ))}
        </div>
      </section>

      {/* ── FEATURES ── */}
      <section id="features" className="py-24 px-6 bg-white/[0.02]">
        <div className="max-w-6xl mx-auto">
          <RevealDiv className="text-center mb-16">
            <span className="text-orange-400 text-sm font-semibold uppercase tracking-widest">Platform Features</span>
            <h2 className="text-4xl font-black mt-3 mb-4" style={{ fontFamily: "'Sora', sans-serif" }}>Built for Impact</h2>
            <p className="text-white/50 max-w-lg mx-auto">Every feature is designed to make animal rescue faster, smarter, and more transparent.</p>
          </RevealDiv>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {FEATURES.map((feat, i) => (
              <RevealDiv key={feat.title} delay={i * 80}>
                <div className="bg-[#0A1A0E] border border-white/8 rounded-2xl p-6 hover:border-emerald-500/25 hover:bg-[#0C1E10] transition-all group cursor-default h-full">
                  <div className="text-3xl mb-4">{feat.icon}</div>
                  <h3 className="text-white font-bold mb-2 group-hover:text-emerald-300 transition-colors" style={{ fontFamily: "'Sora', sans-serif" }}>{feat.title}</h3>
                  <p className="text-white/45 text-sm leading-relaxed">{feat.desc}</p>
                </div>
              </RevealDiv>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY CHOOSE US ── */}
      <section className="py-24 px-6 max-w-6xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <RevealDiv>
            <span className="text-emerald-400 text-sm font-semibold uppercase tracking-widest">Why PawRescue</span>
            <h2 className="text-4xl font-black mt-3 mb-6" style={{ fontFamily: "'Sora', sans-serif" }}>The Smarter Way to Rescue</h2>
            <div className="space-y-4">
              {[
                { icon: "🤖", title: "AI Duplicate Detection", desc: "Prevents multiple reporters for the same animal, saving NGO resources." },
                { icon: "🛡️", title: "100% Verified Network", desc: "Every NGO undergoes background checks and performance monitoring." },
                { icon: "📊", title: "Full Transparency", desc: "See exactly where your donation goes with before/after rescue proof." },
                { icon: "🎮", title: "Gamified Engagement", desc: "Earn coins, climb leaderboards, and unlock badges for every rescue." },
              ].map((item, i) => (
                <div key={item.title} className="flex gap-4 items-start">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/12 border border-emerald-500/20 flex items-center justify-center text-lg flex-shrink-0 mt-0.5">{item.icon}</div>
                  <div>
                    <h4 className="text-white font-semibold mb-1">{item.title}</h4>
                    <p className="text-white/50 text-sm">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </RevealDiv>
          <RevealDiv delay={200}>
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=600&q=80"
                alt="Dog rescue"
                className="w-full rounded-3xl object-cover aspect-square opacity-80"
              />
              <div className="absolute inset-0 rounded-3xl ring-1 ring-white/10" />
              {/* Floating badge */}
              <div className="absolute -bottom-5 -left-5 bg-[#0A1A0E] border border-emerald-500/30 rounded-2xl p-4 shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <p className="text-white font-bold text-sm">Dog Rescued!</p>
                    <p className="text-emerald-400 text-xs">28 min response time</p>
                  </div>
                </div>
              </div>
              <div className="absolute -top-5 -right-5 bg-[#0A1A0E] border border-orange-500/30 rounded-2xl p-4 shadow-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-500/20 flex items-center justify-center">
                    <Award className="w-5 h-5 text-orange-400" />
                  </div>
                  <div>
                    <p className="text-white font-bold text-sm">+50 Coins Earned</p>
                    <p className="text-orange-400 text-xs">Rescue reward</p>
                  </div>
                </div>
              </div>
            </div>
          </RevealDiv>
        </div>
      </section>

      {/* ── IMPACT STATS BAR ── */}
      <section id="impact" className="py-20 px-6 bg-gradient-to-br from-emerald-950/60 to-[#06100A] border-y border-emerald-500/15">
        <div className="max-w-5xl mx-auto">
          <RevealDiv className="text-center mb-12">
            <h2 className="text-3xl font-black" style={{ fontFamily: "'Sora', sans-serif" }}>Real Impact, Real Numbers</h2>
          </RevealDiv>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {IMPACT_STATS.map((stat, i) => (
              <RevealDiv key={stat.label} delay={i * 100} className="text-center">
                <p className={`text-4xl font-black mb-2 ${stat.color}`} style={{ fontFamily: "'Sora', sans-serif" }}>{stat.value}</p>
                <p className="text-white/50 text-sm">{stat.label}</p>
              </RevealDiv>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section className="py-24 px-6 max-w-4xl mx-auto">
        <RevealDiv className="text-center mb-12">
          <span className="text-sky-400 text-sm font-semibold uppercase tracking-widest">Testimonials</span>
          <h2 className="text-4xl font-black mt-3" style={{ fontFamily: "'Sora', sans-serif" }}>Voices of Change</h2>
        </RevealDiv>
        <div className="relative">
          <div className="overflow-hidden rounded-3xl">
            {TESTIMONIALS.map((t, i) => (
              <div
                key={i}
                className="bg-white/[0.04] border border-white/10 rounded-3xl p-8 md:p-10"
                style={{
                  display: i === testimonialIdx ? "block" : "none",
                  animation: "fadeUp 0.4s ease both",
                }}
              >
                <div className="flex items-center gap-1 mb-5">
                  {[...Array(5)].map((_, s) => <Star key={s} className="w-4 h-4 text-amber-400 fill-amber-400" />)}
                </div>
                <p className="text-white/80 text-lg leading-relaxed mb-8 italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white font-bold">{t.avatar}</div>
                  <div>
                    <p className="text-white font-semibold">{t.name}</p>
                    <p className="text-white/45 text-sm">{t.role} · {t.city}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-center gap-2 mt-6">
            {TESTIMONIALS.map((_, i) => (
              <button
                key={i}
                onClick={() => setTestimonialIdx(i)}
                className={`rounded-full transition-all ${i === testimonialIdx ? "w-6 h-2 bg-emerald-500" : "w-2 h-2 bg-white/25"}`}
              />
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section className="py-20 px-6">
        <RevealDiv>
          <div className="max-w-4xl mx-auto relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-600 to-emerald-800 p-12 text-center">
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-16 translate-x-16 blur-2xl" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-black/10 rounded-full translate-y-10 -translate-x-10 blur-xl" />
            <div className="relative">
              <div className="text-5xl mb-4">🐾</div>
              <h2 className="text-4xl font-black mb-4 text-white" style={{ fontFamily: "'Sora', sans-serif" }}>
                Every Second Counts
              </h2>
              <p className="text-emerald-100/80 text-lg mb-8 max-w-lg mx-auto">
                An injured animal is waiting for help right now. Join 52,000+ rescuers making a difference today.
              </p>
              <button
                onClick={() => setPage("login")}
                className="px-8 py-4 rounded-xl bg-white text-emerald-700 font-bold text-lg hover:bg-emerald-50 transition-all shadow-xl"
              >
                Start Rescuing Now →
              </button>
            </div>
          </div>
        </RevealDiv>
      </section>

      {/* ── FOOTER ── */}
      <footer className="border-t border-white/8 py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-10">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
                  <PawPrint className="w-4 h-4 text-white" />
                </div>
                <span className="font-bold text-white" style={{ fontFamily: "'Sora', sans-serif" }}>PawRescue</span>
              </div>
              <p className="text-white/40 text-sm leading-relaxed">India's AI-powered animal rescue and adoption platform. Connecting hearts, saving lives.</p>
            </div>
            {[
              { title: "Platform", links: ["Report Animal", "Lost & Found", "Adopt a Pet", "NGO Directory"] },
              { title: "Community", links: ["Rewards Program", "Volunteer", "NGO Partner", "Blog"] },
              { title: "Company", links: ["About Us", "Privacy Policy", "Terms of Service", "Contact"] },
            ].map((col) => (
              <div key={col.title}>
                <h4 className="text-white font-semibold mb-4 text-sm">{col.title}</h4>
                <ul className="space-y-2">
                  {col.links.map((link) => (
                    <li key={link}><button onClick={() => setPage("login")} className="text-white/40 text-sm hover:text-white/70 transition-colors">{link}</button></li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
          <div className="border-t border-white/8 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-white/30 text-sm">© 2025 PawRescue. Made with 🐾 for animals everywhere.</p>
            <div className="flex items-center gap-4">
              {[<Twitter key="tw" className="w-4 h-4" />, <Instagram key="ig" className="w-4 h-4" />, <Facebook key="fb" className="w-4 h-4" />].map((icon, i) => (
                <button key={i} className="w-9 h-9 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-white/40 hover:text-white/70 hover:bg-white/8 transition-all">
                  {icon}
                </button>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

// ─────────────────────────────────────────────
// LOGIN PAGE
// ─────────────────────────────────────────────
function LoginPage() {
  const { setUser, setPage, addToast } = useApp();
  const [phone, setPhone] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [otpSent, setOtpSent] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [ngoName, setNgoName] = useState("");
  const [loading, setLoading] = useState(false);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);

  const sendOtp = async () => {
    if (phone.length < 10) {
      addToast({ type: "error", title: "Invalid Number", message: "Please enter a valid 10-digit phone number." });
      return;
    }
    setLoading(true);
    try {
      const fullPhone = `+91${phone}`;
      const res = await fetch("http://localhost:5000/api/auth/send-otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: fullPhone }),
      });
      const data = await res.json();
      setLoading(false);
      if (res.ok) {
        setOtpSent(true);
        addToast({ type: "success", title: "OTP Sent!", message: `A 6-digit code was dispatched to +91 ${phone}` });
      } else {
        addToast({ type: "error", title: "Failed to Send OTP", message: data.message || "Error occurred" });
      }
    } catch {
      setLoading(false);
      addToast({ type: "error", title: "Network Error", message: "Backend is unreachable." });
    }
  };

  const handleOtpChange = (i: number, val: string) => {
    if (!/^\d*$/.test(val)) return;
    const next = [...otp];
    next[i] = val.slice(-1);
    setOtp(next);
    if (val && i < 5) otpRefs.current[i + 1]?.focus();
  };

  const verifyOtp = async () => {
    const code = otp.join("");
    if (code.length < 6) {
      addToast({ type: "warning", title: "Incomplete OTP", message: "Please enter all 6 digits." });
      return;
    }
    setLoading(true);
    try {
      const fullPhone = `+91${phone}`;
      const res = await fetch("http://localhost:5000/api/auth/otp", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: fullPhone, code, role: isAdmin ? "admin" : "reporter", name: isAdmin ? ngoName : "" }),
      });
      const data = await res.json();
      setLoading(false);
      if (res.ok) {
        if (data.token) localStorage.setItem("pawrescue_token", data.token);
        const loggedUser = { name: data.user.name, phone: data.user.phone || phone, role: isAdmin ? "admin" : "reporter" };
        localStorage.setItem("pawrescue_user", JSON.stringify(loggedUser));
        setUser(loggedUser as AppUser);
        setPage(isAdmin ? "admin" : "reporter");
        addToast({ type: "success", title: "Welcome back! 🐾", message: "Logged in safely." });
      } else {
        addToast({ type: "error", title: "Login Failed", message: data.message || "Invalid OTP code" });
      }
    } catch {
      setLoading(false);
      addToast({ type: "error", title: "Network Error", message: "Could not reach server" });
    }
  };

  const handleGoogleSuccess = async (credentialResponse: any) => {
    setLoading(true);
    try {
      const res = await fetch("http://localhost:5000/api/auth/google", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ idToken: credentialResponse.credential, role: isAdmin ? "admin" : "reporter", name: isAdmin ? ngoName : "" }),
      });
      const data = await res.json();
      setLoading(false);
      if (res.ok) {
        if (data.token) localStorage.setItem("pawrescue_token", data.token);
        const loggedUser = { name: data.user.name, phone: data.user.phone || "", role: data.user.role || "reporter" };
        localStorage.setItem("pawrescue_user", JSON.stringify(loggedUser));
        setUser(loggedUser as AppUser);
        setPage(data.user.role === "admin" ? "admin" : "reporter");
        addToast({ type: "success", title: "Welcome back! 🐾", message: "Logged in with Google." });
      } else {
        addToast({ type: "error", title: "Login Failed", message: data.message || "Failed to log in with Google" });
      }
    } catch {
      setLoading(false);
      addToast({ type: "error", title: "Network Error", message: "Could not reach server" });
    }
  };

  return (
    <div className="min-h-screen bg-[#06100A] flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 pointer-events-none">
        <img src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?q=80&w=2069" alt="" className="w-full h-full object-cover opacity-15" />
        <div className="absolute inset-0 bg-[#06100A]/80" />
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-emerald-500/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/3 -right-32 w-80 h-80 bg-orange-500/8 rounded-full blur-[100px]" />
      </div>

      <div className="relative w-full max-w-md" style={{ animation: "fadeUp 0.5s ease both" }}>
        {/* Back to landing */}
        <button
          onClick={() => setPage("landing")}
          className="flex items-center gap-1.5 text-white/40 hover:text-white/70 text-sm mb-6 transition-colors"
        >
          ← Back to home
        </button>

        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-600 shadow-lg shadow-emerald-500/30 mb-4">
            <PawPrint className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-white" style={{ fontFamily: "'Sora', sans-serif" }}>PawRescue</h1>
          <p className="text-emerald-400/80 text-sm mt-1">Every paw print matters</p>
        </div>

        {/* Card */}
        <div className="bg-white/[0.04] backdrop-blur-2xl border border-white/10 rounded-3xl p-8 shadow-2xl">
          {/* Role Toggle */}
          <div className="flex bg-white/5 rounded-xl p-1 mb-6 border border-white/10">
            <button
              onClick={() => setIsAdmin(false)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${!isAdmin ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/30" : "text-white/50 hover:text-white/70"}`}
            >
              🐾 Reporter
            </button>
            <button
              onClick={() => setIsAdmin(true)}
              className={`flex-1 py-2.5 rounded-lg text-sm font-semibold transition-all ${isAdmin ? "bg-orange-500 text-white shadow-lg shadow-orange-500/30" : "text-white/50 hover:text-white/70"}`}
            >
              🏢 NGO Admin
            </button>
          </div>

          <div className="space-y-4">
            {!otpSent ? (
              <>
                {isAdmin && (
                  <div>
                    <label className="text-white/60 text-xs font-semibold uppercase tracking-wider mb-2 block">NGO Name</label>
                    <input
                      type="text"
                      value={ngoName}
                      onChange={(e) => setNgoName(e.target.value)}
                      placeholder="e.g. PawCare NGO"
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/25 text-sm focus:outline-none focus:border-orange-500/60 transition-all mb-4"
                    />
                  </div>
                )}
                <div>
                  <label className="text-white/60 text-xs font-semibold uppercase tracking-wider mb-2 block">Phone Number</label>
                  <div className="flex gap-2">
                    <div className="bg-white/5 border border-white/10 rounded-xl px-3 flex items-center text-white/60 text-sm font-medium">+91</div>
                    <input
                      type="tel"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value.replace(/\D/, "").slice(0, 10))}
                      placeholder="98765 43210"
                      className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/25 text-sm focus:outline-none focus:border-emerald-500/60 transition-all"
                    />
                  </div>
                </div>
                <button
                  onClick={sendOtp}
                  disabled={loading}
                  className="w-full py-3.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-emerald-500 to-emerald-600 text-white hover:from-emerald-400 hover:to-emerald-500 transition-all shadow-lg shadow-emerald-500/25 disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                  {loading ? "Sending OTP..." : "Send OTP →"}
                </button>
              </>
            ) : (
              <>
                <div>
                  <label className="text-white/60 text-xs font-semibold uppercase tracking-wider mb-3 block">Enter 6-digit OTP</label>
                  <div className="flex gap-2">
                    {otp.map((digit, i) => (
                      <input
                        key={i}
                        ref={(el) => (otpRefs.current[i] = el)}
                        type="text"
                        value={digit}
                        onChange={(e) => handleOtpChange(i, e.target.value)}
                        onKeyDown={(e) => e.key === "Backspace" && !digit && i > 0 && otpRefs.current[i - 1]?.focus()}
                        className="w-[45px] h-[45px] text-center text-lg font-bold bg-white/5 border border-white/10 rounded-xl text-white focus:outline-none focus:border-emerald-500/60 transition-all shrink-0 sm:w-12 sm:h-12"
                        maxLength={1}
                      />
                    ))}
                  </div>
                  <p className="text-white/40 text-xs mt-2 text-center">
                    Code sent to +91 {phone}{" "}
                    <button onClick={() => setOtpSent(false)} className="text-emerald-400 hover:underline">Change</button>
                  </p>
                </div>
                <button
                  onClick={verifyOtp}
                  disabled={loading}
                  className="w-full py-3.5 rounded-xl font-semibold text-sm bg-gradient-to-r from-emerald-500 to-emerald-600 text-white hover:from-emerald-400 hover:to-emerald-500 transition-all shadow-lg shadow-emerald-500/25 disabled:opacity-60 flex items-center justify-center gap-2"
                >
                  {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Shield className="w-4 h-4" />}
                  {loading ? "Verifying..." : "Verify & Login"}
                </button>
              </>
            )}
          </div>

          <div className="mt-6">
            <div className="relative flex items-center mb-5">
              <div className="flex-grow border-t border-white/10" />
              <span className="flex-shrink-0 mx-4 text-white/30 text-xs font-semibold uppercase tracking-wider">Or</span>
              <div className="flex-grow border-t border-white/10" />
            </div>
            <div className="flex justify-center">
              <GoogleLogin
                onSuccess={handleGoogleSuccess}
                onError={() => addToast({ type: "error", title: "Google Login Error", message: "Pop-up closed or failed." })}
                theme="filled_black"
                shape="rectangular"
                size="large"
              />
            </div>
          </div>

          <p className="text-center text-white/25 text-xs mt-6">
            By continuing, you agree to our{" "}
            <span className="text-emerald-400/60 cursor-pointer hover:text-emerald-400">Terms</span> &{" "}
            <span className="text-emerald-400/60 cursor-pointer hover:text-emerald-400">Privacy Policy</span>
          </p>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// REPORTER HOME DASHBOARD
// ─────────────────────────────────────────────
function ReporterDashboard() {
  const { user, reports, setPage, addToast } = useApp();

  const userReports = reports.filter((r) => r.reporterName === user?.name);
  const coinBalance = userReports.filter((r) => r.status === "completed").length * 50 +
    userReports.filter((r) => r.status !== "fake").length * 10;

  const timelineSteps: { key: ReportStatus; label: string; icon: React.ReactNode }[] = [
    { key: "pending", label: "Submitted", icon: <Clock className="w-3.5 h-3.5" /> },
    { key: "accepted", label: "Accepted", icon: <CheckCircle2 className="w-3.5 h-3.5" /> },
    { key: "in_progress", label: "In Progress", icon: <Activity className="w-3.5 h-3.5" /> },
    { key: "completed", label: "Rescued", icon: <PawPrint className="w-3.5 h-3.5" /> },
  ];

  const getStepIndex = (status: ReportStatus): number => {
    const order: ReportStatus[] = ["pending", "accepted", "in_progress", "completed"];
    return order.indexOf(status);
  };

  const recentReports = userReports.slice(0, 5);

  return (
    <div className="min-h-screen bg-[#0A0F0D] pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#0A0F0D]/85 backdrop-blur-2xl border-b border-white/8">
        <div className="max-w-2xl mx-auto px-5 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
              <PawPrint style={{ width: 18, height: 18 }} className="text-white" />
            </div>
            <div>
              <p className="text-white font-semibold text-sm" style={{ fontFamily: "'Sora', sans-serif" }}>PawRescue</p>
              <p className="text-white/40 text-xs">Welcome, {user?.name?.split(" ")[0]} 👋</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {/* Coin Balance */}
            <div className="flex items-center gap-1.5 bg-amber-500/12 border border-amber-500/25 rounded-xl px-3 py-1.5">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-amber-400 text-xs font-bold">{coinBalance}</span>
            </div>
            <button className="w-9 h-9 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center text-white/50 hover:text-white hover:bg-white/8 transition-all relative">
              <Bell className="w-4 h-4" />
              {userReports.some(r => r.status === "pending") && (
                <span className="absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full bg-red-500" />
              )}
            </button>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-5 py-6 space-y-6">

        {/* Quick Action Hero */}
        <div
          className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-500/20 via-emerald-900/30 to-[#0A0F0D] border border-emerald-500/20 p-6 cursor-pointer hover:border-emerald-500/40 transition-all group"
          onClick={() => setPage("report-form")}
        >
          <div className="absolute top-0 right-0 w-40 h-40 bg-emerald-400/10 rounded-full -translate-y-10 translate-x-10 blur-3xl" />
          <div className="absolute bottom-0 left-0 w-32 h-32 bg-orange-400/5 rounded-full translate-y-8 -translate-x-8 blur-2xl" />
          <div className="relative flex items-center justify-between">
            <div>
              <p className="text-emerald-400 text-xs font-bold uppercase tracking-widest mb-1">Quick Action</p>
              <h2 className="text-white text-xl font-bold mb-1.5" style={{ fontFamily: "'Sora', sans-serif" }}>Report a Stray Animal</h2>
              <p className="text-white/50 text-sm">Spotted an animal in distress? Act fast.</p>
            </div>
            <div className="w-12 h-12 rounded-2xl bg-emerald-500 flex items-center justify-center shadow-lg shadow-emerald-500/40 group-hover:scale-110 group-hover:rotate-3 transition-transform flex-shrink-0">
              <ArrowRight className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-4 gap-2.5">
          {[
            { label: "Reports", value: userReports.length, color: "text-white", bg: "from-white/4 to-white/2", border: "border-white/10" },
            { label: "Active", value: userReports.filter((r) => r.status === "in_progress").length, color: "text-violet-400", bg: "from-violet-500/10 to-violet-900/10", border: "border-violet-500/20" },
            { label: "Rescued", value: userReports.filter((r) => r.status === "completed").length, color: "text-emerald-400", bg: "from-emerald-500/10 to-emerald-900/10", border: "border-emerald-500/20" },
            { label: "Coins", value: coinBalance, color: "text-amber-400", bg: "from-amber-500/10 to-amber-900/10", border: "border-amber-500/20" },
          ].map((s) => (
            <div key={s.label} className={`bg-gradient-to-b ${s.bg} border ${s.border} rounded-2xl p-3 text-center`}>
              <p className={`text-xl font-black ${s.color}`} style={{ fontFamily: "'Sora', sans-serif" }}>{s.value}</p>
              <p className="text-white/40 text-[10px] mt-0.5 font-medium">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Quick Nav Cards */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "Lost & Found", icon: "🔍", page: "discover" as Page, color: "from-sky-500/10 to-sky-900/10", border: "border-sky-500/20", text: "text-sky-400" },
            { label: "Adoption", icon: "🐾", page: "discover" as Page, color: "from-pink-500/10 to-pink-900/10", border: "border-pink-500/20", text: "text-pink-400" },
            { label: "Donate", icon: "❤️", page: "ngo" as Page, color: "from-orange-500/10 to-orange-900/10", border: "border-orange-500/20", text: "text-orange-400" },
          ].map((card) => (
            <button
              key={card.label}
              onClick={() => setPage(card.page)}
              className={`bg-gradient-to-b ${card.color} border ${card.border} rounded-2xl p-4 text-center hover:scale-105 transition-transform`}
            >
              <div className="text-2xl mb-1.5">{card.icon}</div>
              <p className={`text-xs font-semibold ${card.text}`}>{card.label}</p>
            </button>
          ))}
        </div>

        {/* Coins / Rewards Banner */}
        <div
          className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-amber-500/15 to-orange-500/10 border border-amber-500/25 p-4 cursor-pointer hover:border-amber-500/40 transition-all"
          onClick={() => setPage("rewards")}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-2xl">🪙</div>
              <div>
                <p className="text-white font-semibold text-sm">Your Coin Balance</p>
                <p className="text-amber-400 font-black text-lg" style={{ fontFamily: "'Sora', sans-serif" }}>{coinBalance} coins</p>
              </div>
            </div>
            <div className="flex items-center gap-1 text-amber-400 text-xs font-semibold">
              View Rewards <ChevronRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>

        {/* My Reports */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white/70 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
              <Activity className="w-3.5 h-3.5" /> My Reports
            </h3>
            <span className="text-white/30 text-xs">{recentReports.length} reports</span>
          </div>

          {recentReports.length === 0 ? (
            <div className="bg-white/3 border border-white/8 rounded-2xl p-8 text-center">
              <div className="text-4xl mb-3">🐾</div>
              <p className="text-white/50 text-sm font-medium">No reports yet</p>
              <p className="text-white/30 text-xs mt-1">Your rescue reports will appear here</p>
              <button onClick={() => setPage("report-form")} className="mt-4 px-4 py-2 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-sm font-semibold hover:bg-emerald-500/30 transition-all">
                Make Your First Report
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {recentReports.map((report) => {
                const stepIdx = getStepIndex(report.status);
                return (
                  <div
                    key={report.id}
                    className={`bg-white/[0.04] border rounded-2xl overflow-hidden transition-all hover:border-white/20 ${report.isFlagged ? "border-red-500/25 bg-red-500/3" : "border-white/8"}`}
                  >
                    <div className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex items-center gap-3">
                          {report.imageDataUrl && (
                            <img src={report.imageDataUrl} alt="animal" className="w-12 h-12 rounded-xl object-cover border border-white/10 flex-shrink-0" />
                          )}
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="text-white font-semibold text-sm">{report.animalType} — {report.animalCondition}</p>
                              {report.isFlagged && (
                                <span className="bg-red-500/20 border border-red-500/30 text-red-400 text-[10px] px-1.5 py-0.5 rounded-md font-bold">FLAGGED</span>
                              )}
                            </div>
                            <p className="text-white/40 text-xs mt-0.5 flex items-center gap-1">
                              <MapPin className="w-3 h-3" /> {report.location?.address}
                            </p>
                          </div>
                        </div>
                        <StatusBadge status={report.status} />
                      </div>

                      {report.status !== "fake" && (
                        <div className="flex items-center gap-0 mt-3">
                          {timelineSteps.map((step, i) => {
                            const done = i <= stepIdx;
                            const active = i === stepIdx;
                            return (
                              <React.Fragment key={step.key}>
                                <div className="flex flex-col items-center">
                                  <div className={`w-7 h-7 rounded-full flex items-center justify-center border text-xs transition-all ${done ? active ? "bg-emerald-500 border-emerald-500 text-white shadow-lg shadow-emerald-500/40" : "bg-emerald-500/20 border-emerald-500/40 text-emerald-400" : "bg-white/5 border-white/15 text-white/25"}`}>
                                    {step.icon}
                                  </div>
                                  <p className={`text-[9px] mt-1 font-medium whitespace-nowrap ${done ? active ? "text-emerald-400" : "text-emerald-500/60" : "text-white/20"}`}>{step.label}</p>
                                </div>
                                {i < timelineSteps.length - 1 && (
                                  <div className={`flex-1 h-0.5 mb-4 mx-1 rounded-full ${done && i < stepIdx ? "bg-emerald-500/40" : "bg-white/8"}`} />
                                )}
                              </React.Fragment>
                            );
                          })}
                        </div>
                      )}
                      {report.status === "fake" && (
                        <div className="mt-3 flex items-center gap-2 bg-red-500/10 rounded-xl p-3 border border-red-500/20">
                          <XCircle className="w-4 h-4 text-red-400 flex-shrink-0" />
                          <p className="text-red-400 text-xs">This report has been flagged as unverified by our team.</p>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Nearby NGOs Widget */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white/70 text-xs font-bold uppercase tracking-widest flex items-center gap-2">
              <Building2 className="w-3.5 h-3.5" /> Nearby NGOs
            </h3>
            <button onClick={() => setPage("ngo")} className="text-emerald-400 text-xs hover:underline">View All</button>
          </div>
          <div className="space-y-2.5">
            {[
              { name: "Delhi Animal Rescue Trust", dist: "1.2 km", rating: 4.8, status: "Available", reports: 142 },
              { name: "Paws & Claws Foundation", dist: "2.7 km", rating: 4.6, status: "Available", reports: 89 },
              { name: "Stray Help India", dist: "4.1 km", rating: 4.9, status: "Busy", reports: 210 },
            ].map((ngo) => (
              <div key={ngo.name} className="flex items-center gap-3 bg-white/3 border border-white/8 rounded-2xl p-3.5 hover:border-white/15 transition-all">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/20 to-emerald-900/30 border border-emerald-500/20 flex items-center justify-center flex-shrink-0">
                  <Building2 className="w-4.5 h-4.5 text-emerald-400" style={{ width: 18, height: 18 }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-white text-sm font-semibold truncate">{ngo.name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-white/35 text-[10px] flex items-center gap-1"><MapPin className="w-2.5 h-2.5" />{ngo.dist}</span>
                    <span className="text-amber-400 text-[10px]">★ {ngo.rating}</span>
                    <span className="text-white/25 text-[10px]">{ngo.reports} rescues</span>
                  </div>
                </div>
                <span className={`text-[10px] font-bold px-2 py-1 rounded-lg ${ngo.status === "Available" ? "bg-emerald-500/15 text-emerald-400 border border-emerald-500/25" : "bg-amber-500/15 text-amber-400 border border-amber-500/25"}`}>
                  {ngo.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// DISCOVER PAGE (Lost & Found + Adoption)
// ─────────────────────────────────────────────
const MOCK_PETS_ADOPTION = [
  { id: 1, name: "Bruno", type: "Dog", breed: "Labrador Mix", age: "2 years", location: "Delhi", image: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&q=80", status: "adopt", vaccinated: true },
  { id: 2, name: "Whiskers", type: "Cat", breed: "Persian Mix", age: "1 year", location: "Mumbai", image: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=400&q=80", status: "adopt", vaccinated: true },
  { id: 3, name: "Max", type: "Dog", breed: "Indie", age: "3 years", location: "Bangalore", image: "https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400&q=80", status: "adopt", vaccinated: false },
  { id: 4, name: "Luna", type: "Cat", breed: "Siamese Mix", age: "8 months", location: "Chennai", image: "https://images.unsplash.com/photo-1519052537078-e6302a4968d4?w=400&q=80", status: "adopt", vaccinated: true },
];

const MOCK_LOST_FOUND = [
  { id: 1, type: "lost", animal: "Dog", breed: "Golden Retriever", location: "Lodhi Garden, Delhi", description: "Missing since 3 days. Friendly, responds to 'Tiger'.", image: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=400&q=80", aiMatch: true },
  { id: 2, type: "found", animal: "Cat", breed: "Unknown", location: "Bandra, Mumbai", description: "Found near highway. Orange tabby, male, injured paw.", image: "https://images.unsplash.com/photo-1586289883499-f11d28aaf52f?w=400&q=80", aiMatch: false },
  { id: 3, type: "lost", animal: "Dog", breed: "Indie", location: "Koramangala, Bangalore", description: "Brown indie dog with a blue collar. Last seen Monday.", image: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=400&q=80", aiMatch: true },
];

function DiscoverPage() {
  const { setPage } = useApp();
  const [tab, setTab] = useState<"lost" | "adoption">("lost");
  const [filter, setFilter] = useState("All");
  const [selectedPet, setSelectedPet] = useState<typeof MOCK_PETS_ADOPTION[0] | null>(null);

  return (
    <div className="min-h-screen bg-[#0A0F0D] pb-24">
      <header className="sticky top-0 z-40 bg-[#0A0F0D]/85 backdrop-blur-2xl border-b border-white/8">
        <div className="max-w-2xl mx-auto px-5 py-4">
          <div className="flex items-center justify-between mb-3">
            <h1 className="text-white font-bold text-lg" style={{ fontFamily: "'Sora', sans-serif" }}>Discover</h1>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
              <input placeholder="Search..." className="bg-white/5 border border-white/10 rounded-xl pl-8 pr-3 py-2 text-white text-xs focus:outline-none focus:border-emerald-500/50 w-40" />
            </div>
          </div>
          <div className="flex bg-white/5 rounded-xl p-1 border border-white/10">
            <button onClick={() => setTab("lost")} className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${tab === "lost" ? "bg-sky-500 text-white" : "text-white/50"}`}>🔍 Lost & Found</button>
            <button onClick={() => setTab("adoption")} className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${tab === "adoption" ? "bg-pink-500 text-white" : "text-white/50"}`}>🐾 Adoption</button>
          </div>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-5 py-5">
        {tab === "lost" ? (
          <>
            <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
              {["All", "Lost", "Found", "AI Match"].map((f) => (
                <button key={f} onClick={() => setFilter(f)} className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${filter === f ? "bg-sky-500/20 border-sky-500/50 text-sky-300" : "bg-white/4 border-white/10 text-white/45"}`}>
                  {f === "AI Match" ? "🤖 " : ""}{f}
                </button>
              ))}
            </div>
            <div className="space-y-4">
              {MOCK_LOST_FOUND.map((item) => (
                <div key={item.id} className="bg-white/[0.04] border border-white/10 rounded-2xl overflow-hidden hover:border-white/20 transition-all">
                  <div className="flex gap-4 p-4">
                    <img src={item.image} alt={item.animal} className="w-20 h-20 rounded-xl object-cover flex-shrink-0" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-xs font-bold px-2 py-0.5 rounded-lg ${item.type === "lost" ? "bg-red-500/20 text-red-400 border border-red-500/25" : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/25"}`}>
                          {item.type.toUpperCase()}
                        </span>
                        {item.aiMatch && (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-lg bg-violet-500/20 text-violet-400 border border-violet-500/25 flex items-center gap-1">
                            🤖 AI Match
                          </span>
                        )}
                      </div>
                      <p className="text-white font-semibold text-sm">{item.animal} · {item.breed}</p>
                      <p className="text-white/40 text-xs flex items-center gap-1 mt-0.5"><MapPin className="w-2.5 h-2.5" />{item.location}</p>
                      <p className="text-white/55 text-xs mt-1.5 line-clamp-2">{item.description}</p>
                    </div>
                  </div>
                  <div className="px-4 pb-3 flex gap-2">
                    <button className="flex-1 py-2 rounded-xl bg-white/6 border border-white/10 text-white/60 text-xs font-semibold hover:bg-white/10 transition-all">Contact Owner</button>
                    <button className="px-3 py-2 rounded-xl bg-sky-500/20 border border-sky-500/30 text-sky-400 text-xs font-semibold hover:bg-sky-500/30 transition-all">View Detail</button>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-4 py-3 rounded-xl bg-white/4 border border-white/10 text-white/50 text-sm font-semibold hover:bg-white/6 transition-all flex items-center justify-center gap-2">
              <PawPrint className="w-4 h-4" /> Report Lost / Found Pet
            </button>
          </>
        ) : (
          <>
            <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
              {["All", "Dog", "Cat", "Vaccinated"].map((f) => (
                <button key={f} onClick={() => setFilter(f)} className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${filter === f ? "bg-pink-500/20 border-pink-500/50 text-pink-300" : "bg-white/4 border-white/10 text-white/45"}`}>{f}</button>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-3">
              {MOCK_PETS_ADOPTION.map((pet) => (
                <div key={pet.id} onClick={() => setSelectedPet(pet)} className="bg-white/[0.04] border border-white/10 rounded-2xl overflow-hidden hover:border-pink-500/30 hover:scale-[1.02] transition-all cursor-pointer group">
                  <div className="relative aspect-square">
                    <img src={pet.image} alt={pet.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                    {pet.vaccinated && (
                      <div className="absolute top-2 right-2 bg-emerald-500/90 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-lg">✓ Vacc</div>
                    )}
                    <div className="absolute bottom-0 left-0 right-0 p-3">
                      <p className="text-white font-bold text-sm">{pet.name}</p>
                      <p className="text-white/60 text-[10px]">{pet.breed} · {pet.age}</p>
                    </div>
                  </div>
                  <div className="p-3 flex items-center justify-between">
                    <div className="flex items-center gap-1 text-white/40 text-[10px]"><MapPin className="w-2.5 h-2.5" />{pet.location}</div>
                    <button className="px-3 py-1.5 rounded-lg bg-pink-500/20 border border-pink-500/30 text-pink-400 text-[10px] font-bold hover:bg-pink-500/30 transition-all">Adopt Me 🐾</button>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Adoption Modal */}
      {selectedPet && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setSelectedPet(null)}>
          <div className="bg-[#0E1A12] border border-white/12 rounded-3xl w-full max-w-sm overflow-hidden" onClick={(e) => e.stopPropagation()} style={{ animation: "fadeUp 0.3s ease both" }}>
            <img src={selectedPet.image} alt={selectedPet.name} className="w-full aspect-video object-cover" />
            <div className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="text-white font-bold text-xl" style={{ fontFamily: "'Sora', sans-serif" }}>{selectedPet.name}</h3>
                  <p className="text-white/50 text-sm">{selectedPet.breed} · {selectedPet.age}</p>
                </div>
                {selectedPet.vaccinated && <span className="bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 text-xs font-semibold px-2 py-1 rounded-lg">✓ Vaccinated</span>}
              </div>
              <p className="text-white/50 text-sm mb-4 flex items-center gap-1"><MapPin className="w-3.5 h-3.5 text-orange-400" />{selectedPet.location}</p>
              <div className="flex gap-2">
                <button onClick={() => setSelectedPet(null)} className="flex-1 py-3 rounded-xl bg-white/6 border border-white/10 text-white/60 text-sm font-semibold">Close</button>
                <button className="flex-[2] py-3 rounded-xl bg-gradient-to-r from-pink-500 to-pink-600 text-white text-sm font-bold shadow-lg shadow-pink-500/30">
                  🐾 Adopt {selectedPet.name}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// NGO & DONATION PAGE
// ─────────────────────────────────────────────
const MOCK_NGOS = [
  { id: 1, name: "Delhi Animal Rescue Trust", city: "New Delhi", dist: "1.2 km", rating: 4.8, rescues: 142, image: "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?w=300&q=80", verified: true },
  { id: 2, name: "Paws & Claws Foundation", city: "New Delhi", dist: "2.7 km", rating: 4.6, rescues: 89, image: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=300&q=80", verified: true },
  { id: 3, name: "Stray Help India", city: "New Delhi", dist: "4.1 km", rating: 4.9, rescues: 210, image: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=300&q=80", verified: true },
];

function NGOPage() {
  const { addToast } = useApp();
  const [donationView, setDonationView] = useState(false);
  const [selectedNGO, setSelectedNGO] = useState<typeof MOCK_NGOS[0] | null>(null);
  const [amount, setAmount] = useState(500);
  const [donated, setDonated] = useState(false);

  const handleDonate = () => {
    setDonated(true);
    setTimeout(() => { setDonated(false); setDonationView(false); }, 3000);
    addToast({ type: "success", title: "Donation Successful! 💚", message: `₹${amount} sent to ${selectedNGO?.name}` });
  };

  return (
    <div className="min-h-screen bg-[#0A0F0D] pb-24">
      <header className="sticky top-0 z-40 bg-[#0A0F0D]/85 backdrop-blur-2xl border-b border-white/8">
        <div className="max-w-2xl mx-auto px-5 py-4">
          <h1 className="text-white font-bold text-lg" style={{ fontFamily: "'Sora', sans-serif" }}>NGOs & Donate</h1>
          <p className="text-white/40 text-xs mt-0.5">Verified animal welfare organizations near you</p>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-5 py-5 space-y-4">
        {/* Impact banner */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-orange-500/15 to-red-500/10 border border-orange-500/25 p-4">
          <div className="flex items-center gap-3">
            <div className="text-3xl">❤️</div>
            <div>
              <p className="text-white font-semibold text-sm">Your donations save lives</p>
              <p className="text-white/50 text-xs mt-0.5">100% transparent — see where every rupee goes</p>
            </div>
          </div>
        </div>

        {/* NGO Cards */}
        {MOCK_NGOS.map((ngo) => (
          <div key={ngo.id} className="bg-white/[0.04] border border-white/10 rounded-2xl overflow-hidden hover:border-white/20 transition-all">
            <div className="flex gap-4 p-4">
              <img src={ngo.image} alt={ngo.name} className="w-16 h-16 rounded-xl object-cover flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <p className="text-white font-bold text-sm truncate">{ngo.name}</p>
                  {ngo.verified && <span className="text-sky-400 text-[10px]">✓</span>}
                </div>
                <div className="flex items-center gap-3 text-[10px] text-white/40">
                  <span className="flex items-center gap-0.5"><MapPin className="w-2.5 h-2.5" />{ngo.dist}</span>
                  <span className="text-amber-400">★ {ngo.rating}</span>
                  <span>{ngo.rescues} rescues</span>
                </div>
              </div>
            </div>
            {/* Transparency bar */}
            <div className="px-4 pb-2">
              <p className="text-white/30 text-[10px] mb-1.5">Fund allocation</p>
              <div className="flex gap-1 h-1.5 rounded-full overflow-hidden">
                <div className="bg-emerald-500 rounded-full" style={{ width: "60%" }} />
                <div className="bg-sky-500 rounded-full" style={{ width: "25%" }} />
                <div className="bg-orange-500 rounded-full" style={{ width: "15%" }} />
              </div>
              <div className="flex gap-4 mt-1.5 text-[9px] text-white/35">
                <span><span className="text-emerald-400">●</span> 60% Medical</span>
                <span><span className="text-sky-400">●</span> 25% Shelter</span>
                <span><span className="text-orange-400">●</span> 15% Ops</span>
              </div>
            </div>
            <div className="px-4 pb-4 flex gap-2">
              <button className="flex-1 py-2 rounded-xl bg-white/6 border border-white/10 text-white/60 text-xs font-semibold hover:bg-white/10 transition-all">View Profile</button>
              <button
                onClick={() => { setSelectedNGO(ngo); setDonationView(true); }}
                className="flex-1 py-2 rounded-xl bg-orange-500/20 border border-orange-500/30 text-orange-400 text-xs font-bold hover:bg-orange-500/30 transition-all flex items-center justify-center gap-1"
              >
                <HandHeart className="w-3.5 h-3.5" /> Donate
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Donation Modal */}
      {donationView && selectedNGO && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-4" onClick={() => setDonationView(false)}>
          <div className="bg-[#0E1A12] border border-white/12 rounded-3xl w-full max-w-sm p-6" onClick={(e) => e.stopPropagation()} style={{ animation: "fadeUp 0.3s ease both" }}>
            {donated ? (
              <div className="text-center py-8">
                <div className="text-6xl mb-4">🎉</div>
                <h3 className="text-white font-bold text-xl mb-2" style={{ fontFamily: "'Sora', sans-serif" }}>Thank You!</h3>
                <p className="text-emerald-400">₹{amount} donated successfully</p>
              </div>
            ) : (
              <>
                <h3 className="text-white font-bold text-lg mb-1" style={{ fontFamily: "'Sora', sans-serif" }}>Donate to NGO</h3>
                <p className="text-white/50 text-sm mb-5">{selectedNGO.name}</p>
                <div className="grid grid-cols-4 gap-2 mb-4">
                  {[100, 250, 500, 1000].map((a) => (
                    <button key={a} onClick={() => setAmount(a)} className={`py-2.5 rounded-xl text-sm font-bold border transition-all ${amount === a ? "bg-orange-500/25 border-orange-500/50 text-orange-300" : "bg-white/5 border-white/10 text-white/50"}`}>
                      ₹{a}
                    </button>
                  ))}
                </div>
                <input
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(parseInt(e.target.value) || 0)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white text-sm focus:outline-none focus:border-orange-500/50 mb-4"
                  placeholder="Custom amount..."
                />
                <div className="flex gap-2">
                  <button onClick={() => setDonationView(false)} className="flex-1 py-3 rounded-xl bg-white/6 border border-white/10 text-white/60 text-sm font-semibold">Cancel</button>
                  <button onClick={handleDonate} className="flex-[2] py-3 rounded-xl bg-gradient-to-r from-orange-500 to-orange-600 text-white text-sm font-bold shadow-lg shadow-orange-500/30">
                    ❤️ Donate ₹{amount}
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// REWARDS PAGE
// ─────────────────────────────────────────────
function RewardsPage() {
  const { user, reports } = useApp();
  const userReports = reports.filter((r) => r.reporterName === user?.name);
  const coinBalance = userReports.filter((r) => r.status === "completed").length * 50 +
    userReports.filter((r) => r.status !== "fake").length * 10;

  const rewards = [
    { id: 1, title: "Donate to NGO", desc: "Contribute 100 coins as ₹50 to any NGO", cost: 100, icon: "❤️" },
    { id: 2, title: "Rescue Badge", desc: "Exclusive 'Animal Guardian' profile badge", cost: 250, icon: "🏅" },
    { id: 3, title: "Priority Response", desc: "Your reports get priority NGO attention", cost: 500, icon: "⚡" },
    { id: 4, title: "VIP Rescuer", desc: "VIP status + featured on our leaderboard", cost: 1000, icon: "👑" },
  ];

  const rewardHistory = [
    { action: "Report submitted", coins: "+10", time: "2h ago" },
    { action: "Report accepted", coins: "+15", time: "5h ago" },
    { action: "Animal rescued!", coins: "+50", time: "1d ago" },
    { action: "Community bonus", coins: "+25", time: "3d ago" },
  ];

  return (
    <div className="min-h-screen bg-[#0A0F0D] pb-24">
      <header className="sticky top-0 z-40 bg-[#0A0F0D]/85 backdrop-blur-2xl border-b border-white/8">
        <div className="max-w-2xl mx-auto px-5 py-4">
          <h1 className="text-white font-bold text-lg" style={{ fontFamily: "'Sora', sans-serif" }}>Rewards</h1>
          <p className="text-white/40 text-xs mt-0.5">Earn coins, redeem for good</p>
        </div>
      </header>

      <div className="max-w-2xl mx-auto px-5 py-5 space-y-6">
        {/* Balance Hero */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-amber-500/20 via-orange-500/10 to-[#0A0F0D] border border-amber-500/25 p-6">
          <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full -translate-y-8 translate-x-8 blur-2xl" />
          <div className="relative text-center">
            <div className="text-5xl mb-3">🪙</div>
            <p className="text-white/60 text-sm mb-1">Your Balance</p>
            <p className="text-5xl font-black text-amber-400" style={{ fontFamily: "'Sora', sans-serif" }}>{coinBalance}</p>
            <p className="text-white/40 text-sm mt-1">coins</p>
          </div>
          <div className="relative grid grid-cols-3 gap-3 mt-5">
            {[
              { label: "Reports", value: userReports.length, coin: `+${userReports.length * 10}` },
              { label: "Rescues", value: userReports.filter(r => r.status === "completed").length, coin: `+${userReports.filter(r => r.status === "completed").length * 50}` },
              { label: "Streak", value: "3 days", coin: "+bonus" },
            ].map((s) => (
              <div key={s.label} className="bg-black/20 border border-white/8 rounded-xl p-3 text-center">
                <p className="text-white font-bold text-sm">{s.value}</p>
                <p className="text-white/40 text-[10px]">{s.label}</p>
                <p className="text-amber-400 text-[9px] mt-0.5">{s.coin}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Redeem Options */}
        <div>
          <h3 className="text-white/70 text-xs font-bold uppercase tracking-widest mb-3">Redeem Rewards</h3>
          <div className="grid grid-cols-2 gap-3">
            {rewards.map((reward) => {
              const canRedeem = coinBalance >= reward.cost;
              return (
                <div key={reward.id} className={`border rounded-2xl p-4 transition-all ${canRedeem ? "bg-white/[0.04] border-white/10 hover:border-amber-500/30 cursor-pointer" : "bg-white/2 border-white/6 opacity-60"}`}>
                  <div className="text-3xl mb-3">{reward.icon}</div>
                  <p className="text-white font-bold text-sm mb-1">{reward.title}</p>
                  <p className="text-white/40 text-xs mb-3 leading-relaxed">{reward.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-amber-400 text-xs font-bold">🪙 {reward.cost}</span>
                    <button disabled={!canRedeem} className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition-all ${canRedeem ? "bg-amber-500/20 border border-amber-500/30 text-amber-400 hover:bg-amber-500/30" : "bg-white/5 text-white/25 border border-white/8"}`}>
                      {canRedeem ? "Redeem" : "Locked"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* History */}
        <div>
          <h3 className="text-white/70 text-xs font-bold uppercase tracking-widest mb-3">Coin History</h3>
          <div className="bg-white/[0.04] border border-white/8 rounded-2xl overflow-hidden">
            {rewardHistory.map((h, i) => (
              <div key={i} className={`flex items-center justify-between px-4 py-3.5 ${i < rewardHistory.length - 1 ? "border-b border-white/6" : ""}`}>
                <div>
                  <p className="text-white text-sm font-medium">{h.action}</p>
                  <p className="text-white/35 text-xs">{h.time}</p>
                </div>
                <span className="text-emerald-400 font-bold text-sm">{h.coins}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Leaderboard Teaser */}
        <div className="bg-gradient-to-r from-violet-500/10 to-sky-500/10 border border-violet-500/20 rounded-2xl p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white font-bold text-sm">Community Leaderboard</p>
              <p className="text-white/50 text-xs mt-0.5">Rank #47 · Top 10% of rescuers</p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 flex items-center justify-center">
              <TrendingUp className="w-5 h-5 text-violet-400" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// BOTTOM NAV
// ─────────────────────────────────────────────
function BottomNav({ role }: { role: "reporter" | "admin" }) {
  const { page, setPage, setUser, user, reports } = useApp();
  const userReports = reports.filter((r) => r.reporterName === user?.name);

  const reporterItems = [
    { id: "reporter" as Page, label: "Home", icon: <LayoutDashboard className="w-5 h-5" /> },
    { id: "discover" as Page, label: "Discover", icon: <Compass className="w-5 h-5" /> },
    { id: "report-form" as Page, label: "Report", icon: <AlertTriangle className="w-5 h-5" />, featured: true },
    { id: "ngo" as Page, label: "NGOs", icon: <Building2 className="w-5 h-5" /> },
    { id: "rewards" as Page, label: "Rewards", icon: <Coins className="w-5 h-5" /> },
  ];

  const adminItems = [
    { id: "admin" as Page, label: "Dashboard", icon: <Activity className="w-5 h-5" /> },
  ];

  const items = role === "reporter" ? reporterItems : adminItems;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#0A0F0D]/92 backdrop-blur-2xl border-t border-white/8 z-50">
      <div className="max-w-2xl mx-auto px-4 py-2 flex items-center justify-around">
        {items.map((item) =>
          (item as any).featured ? (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className="flex flex-col items-center gap-0.5 relative -top-3"
            >
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-all ${page === item.id ? "bg-emerald-400 shadow-emerald-400/50" : "bg-emerald-500 shadow-emerald-500/40 hover:bg-emerald-400"}`}>
                {item.icon}
              </div>
              <span className="text-[9px] font-bold text-emerald-400">{item.label}</span>
            </button>
          ) : (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={`flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl transition-all relative ${page === item.id ? "text-emerald-400" : "text-white/30 hover:text-white/60"}`}
            >
              {item.icon}
              <span className="text-[9px] font-semibold">{item.label}</span>
              {item.id === "reporter" && userReports.some(r => r.status === "pending") && (
                <span className="absolute top-1 right-2 w-1.5 h-1.5 rounded-full bg-red-500" />
              )}
              {page === item.id && <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-emerald-400" />}
            </button>
          )
        )}
        <button
          onClick={() => {
            localStorage.removeItem("pawrescue_token");
            localStorage.removeItem("pawrescue_user");
            setUser(null);
            setPage("landing");
            window.location.reload();
          }}
          className="flex flex-col items-center gap-1 px-3 py-1.5 rounded-xl text-white/30 hover:text-red-400 transition-all"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-[9px] font-semibold">Logout</span>
        </button>
      </div>
    </nav>
  );
}

// ─────────────────────────────────────────────
// PAGE LOADER
// ─────────────────────────────────────────────
function PageLoader() {
  return (
    <div className="min-h-screen bg-[#0A0F0D] flex items-center justify-center">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center">
          <PawPrint className="w-6 h-6 text-emerald-400 animate-bounce" />
        </div>
        <div className="flex gap-1.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="w-2 h-2 rounded-full bg-emerald-500/60 animate-bounce" style={{ animationDelay: `${i * 0.15}s` }} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────
// APP PROVIDER & ROOT ROUTER
// ─────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState<Page>(() => {
    const saved = localStorage.getItem("pawrescue_user");
    if (saved) {
      try {
        const u = JSON.parse(saved);
        return u.role === "admin" ? "admin" : "reporter";
      } catch { return "landing"; }
    }
    return "landing";
  });

  const [user, setUser] = useState<AppUser | null>(() => {
    const saved = localStorage.getItem("pawrescue_user");
    if (saved) { try { return JSON.parse(saved); } catch { return null; } }
    return null;
  });

  const [reports, setReports] = useState<AnimalReport[]>([]);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [imageHashes, setImageHashes] = useState<Set<string>>(new Set());

  useEffect(() => {
    const fetchReports = async () => {
      try {
        const res = await fetch("http://localhost:5000/api/reports");
        const data = await res.json();
        const formatted = data.map((r: any) => ({ ...r, id: r._id || r.originalId }));
        setReports(formatted);
        setImageHashes(new Set(formatted.filter((r: any) => r.imageHash).map((r: any) => r.imageHash)));
      } catch (err) {
        console.error("Failed to fetch reports", err);
      }
    };
    fetchReports();

    const socket = io("http://localhost:5000");
    socket.on("new_report", (newReport) => {
      const formatted = { ...newReport, id: newReport._id || newReport.originalId };
      setReports((prev) => [formatted, ...prev]);
      if (formatted.imageHash) setImageHashes((prev) => new Set(prev).add(formatted.imageHash));
    });

    socket.on("status_update", (payload) => {
      setReports((prev) =>
        prev.map((r) =>
          r.id === payload.id
            ? { ...r, status: payload.status, treatedImageUrl: payload.treatedImageUrl || r.treatedImageUrl, isFlagged: payload.status === "fake", updatedAt: new Date() }
            : r
        )
      );
    });

    return () => { socket.disconnect(); };
  }, []);

  const addToast = useCallback((t: Omit<ToastItem, "id">) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { ...t, id }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const addReport = useCallback((r: AnimalReport) => {
    setReports((prev) => [r, ...prev]);
  }, []);

  const updateReportStatus = useCallback(async (id: string, status: ReportStatus, treatedImageDataUrl?: string) => {
    try {
      const res = await fetch(`http://localhost:5000/api/reports/${id}/status`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status, treatedImageDataUrl }),
      });
      if (res.ok) {
        const updatedReport = await res.json();
        setReports((prev) =>
          prev.map((r) =>
            r.id === id
              ? { ...r, status, treatedImageUrl: updatedReport.treatedImageUrl || r.treatedImageUrl, isFlagged: status === "fake", updatedAt: new Date() }
              : r
          )
        );
      }
    } catch (err) {
      console.error("Failed to patch status:", err);
    }
  }, []);

  const registerHash = useCallback((hash: string) => {
    setImageHashes((prev) => new Set(prev).add(hash));
  }, []);

  const AdminDashboard = React.lazy(() => import("./AdminDashboard"));
  const ReportWizard = React.lazy(() => import("./CameraModule").then((m) => ({ default: m.ReportWizard })));

  const renderPage = () => {
    if (!user) {
      if (page === "login") return <LoginPage />;
      return <LandingPage />;
    }
    if (user.role === "admin") {
      return (
        <React.Suspense fallback={<PageLoader />}>
          <AdminDashboard />
        </React.Suspense>
      );
    }
    // Reporter pages
    const withNav = (content: React.ReactNode) => (
      <>
        {content}
        <BottomNav role={user.role} />
      </>
    );

    switch (page) {
      case "reporter": return withNav(<ReporterDashboard />);
      case "report-form": return withNav(<React.Suspense fallback={<PageLoader />}><ReportWizard /></React.Suspense>);
      case "discover": return withNav(<DiscoverPage />);
      case "ngo": return withNav(<NGOPage />);
      case "rewards": return withNav(<RewardsPage />);
      default: return withNav(<ReporterDashboard />);
    }
  };

  return (
    <AppContext.Provider
      value={{ page, setPage, user, setUser, reports, addReport, updateReportStatus, toasts, addToast, removeToast, imageHashes, registerHash }}
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800;900&family=DM+Sans:ital,opsz,wght@0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; font-family: 'DM Sans', sans-serif; background: #0A0F0D; }
        @keyframes slideIn { from { transform: translateX(120%); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeUp { from { transform: translateY(20px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes shrink { from { transform: scaleX(1); } to { transform: scaleX(0); } }
        @keyframes countPop { from { transform: scale(1.8); opacity: 0; } to { transform: scale(1); opacity: 1; } }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 4px; }
      `}</style>
      {renderPage()}
      <ToastContainer />
    </AppContext.Provider>
  );
}
